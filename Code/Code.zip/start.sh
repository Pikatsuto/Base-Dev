python3 start.py
read -p "Press any key to exit"
clear