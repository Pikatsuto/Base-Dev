import os, shutil
from command import ErrorAndLog
from command.Console import consoleInput

def checkEnv():
    try:
        if not os.path.exists(".env"):
            ErrorAndLog.pythonSys("-m venv .env")
            ErrorAndLog.python("-m pip install --upgrade pip")

    except Exception as e:
        return ErrorAndLog.error(e, "StartPrograme checkEnv")


def checkAndInstall():
    try:
        if not os.path.exists("database"):
            os.makedirs("database")

        if not os.path.exists("command"):
            return(ErrorAndLog.error("[FATAL] Command folder missing", "StartPrograme CheckAndInstall"))

    except Exception as e:
        return ErrorAndLog.error(e, "StartPrograme CheckAndInstall")


def startAndRestart():
    try:
        while True:
            ErrorAndLog.python("main.py")
            
            if not os.path.exists("database/restart"):
                break
            else:
                shutil.rmtree("database/restart")
        
    except Exception as e:
        return ErrorAndLog.error(e, "StartPrograme startAndRestart")


def startInit():
    try:
        checkEnv()
        checkAndInstall()
        startAndRestart()

    except Exception as e:
        return ErrorAndLog.error(e, "StartPrograme startInit")

startInit()